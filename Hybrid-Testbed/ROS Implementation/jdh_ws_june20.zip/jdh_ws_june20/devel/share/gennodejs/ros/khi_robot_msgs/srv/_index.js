
"use strict";

let KhiRobotCmd = require('./KhiRobotCmd.js')

module.exports = {
  KhiRobotCmd: KhiRobotCmd,
};
